import EquipmentEx.OutfitSystem

@addMethod(GameObject)
public final func NightCoopReadOutfitSlot(slotID: TweakDBID) -> ItemID {
    let localPlayer = GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerMainGameObject();
    if IsDefined(localPlayer) && Equals(this.GetEntityID(), localPlayer.GetEntityID()) {
        let outfit = OutfitSystem.GetInstance(this.GetGame());
        if IsDefined(outfit) && outfit.IsActive() && outfit.IsOutfitSlot(slotID) {
            return outfit.NightCoopReadConfiguredItem(slotID);
        }
    }

    // Other actors and ordinary equipment slots retain the original reader.
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    let item = transactions.GetItemInSlot(this, slotID);
    if IsDefined(item) {
        return item.GetItemID();
    }

    return ItemID.None();
}
