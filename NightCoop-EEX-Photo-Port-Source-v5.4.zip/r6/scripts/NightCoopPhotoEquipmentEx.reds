module EquipmentEx

// NightCoop clones these records at runtime. Ensure its clones inherit EVERY
// installed extra slot even when E-EX's display-name/template heuristic skips them.
public class NightCoopPhotoExtraSlotRegistration extends ScriptableTweak {
    protected func OnApply() -> Void {
        let batch = TweakDBManager.StartBatch();
        for recordID in [t"Character.TPP_Player_Cutscene_Female", t"Character.TPP_Player_Cutscene_Male"] {
            let slots = TweakDBInterface.GetForeignKeyArray(recordID + t".attachmentSlots");
            for extra in OutfitConfig.OutfitSlots() {
                if !ArrayContains(slots, extra.slotID) { ArrayPush(slots, extra.slotID); }
            }
            batch.SetFlat(recordID + t".attachmentSlots", slots);
            batch.UpdateRecord(recordID);
        }
        batch.Commit();
    }
}

@addMethod(GameObject)
public final func NightCoopPhotoIdentity() -> String {
    let puppet = this as ScriptedPuppet;
    if !IsDefined(puppet) { return "not a scripted puppet"; }
    let record = puppet.GetRecord();
    if !IsDefined(record) { return "waiting: no character record"; }
    return s"record=\(TDBID.ToStringDEBUG(record.GetRecordID())); template=\(ResRef.ToString(this.GetTemplatePath()))";
}

@addMethod(GameObject)
public final func NightCoopIsReceivedPhoto() -> Bool {
    if !IsDefined(this as NPCPuppet) { return false; }
    let localPhoto = GameInstance.GetPlayerSystem(this.GetGame()).GetPhotoPuppet();
    if IsDefined(localPhoto) && Equals(localPhoto.GetEntityID(), this.GetEntityID()) {
        return false;
    }
    let puppet = this as ScriptedPuppet;
    let record = puppet.GetRecord();
    if !IsDefined(record) || Equals(record.GetRecordID(), t"Character.Player_Puppet_Photomode") {
        return false;
    }
    // Native-created TweakDB records need not have registered DEBUG names.
    // Compare resource hashes instead of relying on their printable names.
    let template = this.GetTemplatePath();
    if !Equals(template, r"base\\characters\\entities\\player\\photo_mode\\player_wa_photomode.ent")
        && !Equals(template, r"base\\characters\\entities\\player\\photo_mode\\player_ma_photomode.ent") {
        return false;
    }
    for component in this.GetComponents() {
        if IsDefined(component as PhotoModePlayerEntityComponent) { return true; }
    }
    return false;
}

// Receiver only: inspect the LIVE actor's record and photo component directly.
// Never reads the viewer's saved outfit parts and never modifies item records.
@addMethod(GameObject)
public final func NightCoopRepairPhotoExtraSlots() -> String {
    if !this.NightCoopIsReceivedPhoto() {
        return "skipped: not a NightCoop remote photo actor";
    }
    let puppet = this as NPCPuppet;
    if !IsDefined(puppet) {
        return "skipped: not a photo NPC";
    }

    let isPhoto = false;
    for component in this.GetComponents() {
        if IsDefined(component as PhotoModePlayerEntityComponent) {
            isPhoto = true;
            break;
        }
    }
    if !isPhoto {
        return "skipped: no photo component";
    }

    let playerSystem = GameInstance.GetPlayerSystem(this.GetGame());
    let localPhoto = playerSystem.GetPhotoPuppet();
    if IsDefined(localPhoto) && Equals(localPhoto.GetEntityID(), this.GetEntityID()) {
        return "skipped: viewer's own photo actor";
    }

    let outfit = OutfitSystem.GetInstance(this.GetGame());
    if !IsDefined(outfit) {
        return "skipped: Equipment-EX unavailable";
    }
    let extraSlots = outfit.GetOutfitSlots();
    let recordSlots = TweakDBInterface.GetForeignKeyArray(puppet.GetRecord().GetRecordID() + t".attachmentSlots");
    let registered = 0;
    for slot in extraSlots {
        if ArrayContains(recordSlots, slot) { registered += 1; }
    }
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    let inventory: array<wref<gameItemData>>;
    if !transactions.GetItemList(this, inventory) {
        return "waiting: received actor inventory unavailable";
    }

    let mapped = 0;
    let correct = 0;
    let restored = 0;
    let overflow = 0;
    let conflicts = 0;
    let failed = 0;
    let reservedSlots: array<TweakDBID>;
    for data in inventory {
        if IsDefined(data) {
            let placement = TweakDBInterface.GetForeignKeyArray(ItemID.GetTDBID(data.GetID()) + t".placementSlots");
            if ArraySize(placement) > 0 && ArrayContains(extraSlots, ArrayLast(placement)) {
                ArrayPush(reservedSlots, ArrayLast(placement));
            }
        }
    }
    for data in inventory {
        if IsDefined(data) {
            let result = this.NightCoopRepairPhotoExtraItem(data.GetID(), extraSlots, reservedSlots);
            if result > 0 { mapped += 1; }
            if result == 1 { correct += 1; }
            if result == 2 { restored += 1; }
            if result == 3 { conflicts += 1; }
            if result == 4 { failed += 1; }
            if result == 5 { overflow += 1; }
        }
    }
    return s"EX slots \(ArraySize(extraSlots)); actor record registers \(registered); inventory \(ArraySize(inventory)); mapped \(mapped); correct \(correct); restored \(restored); overflow \(overflow); conflicts \(conflicts); failed \(failed)";
}

@addMethod(GameObject)
public final func NightCoopPhotoInventoryReport() -> String {
    if !this.NightCoopIsReceivedPhoto() { return "excluded"; }
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    let inventory: array<wref<gameItemData>>;
    let report = "";
    transactions.GetItemList(this, inventory);
    let extraSlots = OutfitSystem.GetInstance(this.GetGame()).GetOutfitSlots();
    for data in inventory {
        if IsDefined(data) {
            let itemID = data.GetID();
            let itemName = TDBID.ToStringDEBUG(ItemID.GetTDBID(itemID));
            let equipped = "none";
            let placements = "";
            for slot in TweakDBInterface.GetForeignKeyArray(ItemID.GetTDBID(itemID) + t".placementSlots") {
                placements += s"\(TDBID.ToStringDEBUG(slot)),";
            }
            for slot in extraSlots {
                let item = transactions.GetItemInSlot(this, slot);
                if IsDefined(item) && Equals(item.GetItemID(), itemID) {
                    equipped = s"\(TDBID.ToStringDEBUG(slot)) components=\(ArraySize(item.GetComponents())) visualAttached=\(item.IsVisualSpawnAttached())";
                }
            }
            report += s"[\(itemName) EX=\(equipped) targets=\(placements)] ";
        }
    }
    return report;
}

@addMethod(GameObject)
private final func NightCoopRepairPhotoExtraItem(itemID: ItemID, extraSlots: array<TweakDBID>, reservedSlots: array<TweakDBID>) -> Int32 {
    let recordID = ItemID.GetTDBID(itemID);
    if !IsDefined(TweakDBInterface.GetClothingRecord(recordID)) { return 0; }
    let supportedSlots = TweakDBInterface.GetForeignKeyArray(recordID + t".placementSlots");
    if ArraySize(supportedSlots) == 0 { return 0; }
    // Equipment-EX itself selects the LAST placement slot (GetItemSlot).
    let extraSlot = ArrayLast(supportedSlots);
    if !ArrayContains(extraSlots, extraSlot) { return 0; }
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    // Already displayed in any extra slot, including one allocated on an earlier pass.
    for slot in extraSlots {
        let existing = transactions.GetItemInSlot(this, slot);
        if IsDefined(existing) && Equals(existing.GetItemID(), itemID) { return 1; }
    }
    let usedOverflow = false;
    let current = transactions.GetItemInSlot(this, extraSlot);
    if IsDefined(current) {
        let substitute = this.NightCoopFindPhotoExtraSlot(extraSlot, extraSlots, reservedSlots);
        if !TDBID.IsValid(substitute) { return 3; }
        extraSlot = substitute;
        usedOverflow = true;
    }

    let previousSlot = TDBID.None();
    for slot in supportedSlots {
        if NotEquals(slot, extraSlot) {
            let previous = transactions.GetItemInSlot(this, slot);
            if IsDefined(previous) && Equals(previous.GetItemID(), itemID) {
                previousSlot = slot;
                break;
            }
        }
    }
    if TDBID.IsValid(previousSlot) {
        transactions.RemoveItemFromSlot(this, previousSlot);
    }
    // Keep the FULL received preview ItemID, including instance fields.
    if transactions.AddItemToSlot(this, extraSlot, itemID, true) { return usedOverflow ? 5 : 2; }
    if TDBID.IsValid(previousSlot) {
        transactions.AddItemToSlot(this, previousSlot, itemID, true);
    }
    return 4;
}

@addMethod(GameObject)
private final func NightCoopFindPhotoExtraSlot(preferred: TweakDBID, extraSlots: array<TweakDBID>, reserved: array<TweakDBID>) -> TweakDBID {
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    let parent = FromVariant<TweakDBID>(TweakDBInterface.GetFlat(preferred + t".parentSlot"));
    let dependencies = TweakDBInterface.GetForeignKeyArray(preferred + t".dependencySlots");
    for candidate in extraSlots {
        if !ArrayContains(reserved, candidate) && !IsDefined(transactions.GetItemInSlot(this, candidate)) {
            let candidateParent = FromVariant<TweakDBID>(TweakDBInterface.GetFlat(candidate + t".parentSlot"));
            let candidateDependencies = TweakDBInterface.GetForeignKeyArray(candidate + t".dependencySlots");
            let matches = Equals(parent, candidateParent) && ArraySize(dependencies) == ArraySize(candidateDependencies);
            for dependency in dependencies {
                if !ArrayContains(candidateDependencies, dependency) { matches = false; }
            }
            if matches { return candidate; }
        }
    }
    return TDBID.None();
}


// v5 SDK bridge: transmit only the source player's configured EX placement.
@addMethod(GameObject)
public final func NightCoopPhotoConfiguredSlots() -> array<TweakDBID> {
    let result: array<TweakDBID>;
    let localPlayer = GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerMainGameObject();
    if !IsDefined(localPlayer) || NotEquals(localPlayer.GetEntityID(), this.GetEntityID()) { return result; }
    let outfit = OutfitSystem.GetInstance(this.GetGame());
    if !IsDefined(outfit) || !outfit.IsActive() { return result; }
    for slot in outfit.GetOutfitSlots() {
        let item = outfit.NightCoopReadConfiguredItem(slot);
        if ItemID.IsValid(item) && IsDefined(TweakDBInterface.GetClothingRecord(ItemID.GetTDBID(item))) {
            ArrayPush(result, slot);
            ArrayPush(result, ItemID.GetTDBID(item));
        }
    }
    return result;
}

@addMethod(GameObject)
public final func NightCoopPhotoMatchSlots(snapshot: array<TweakDBID>) -> Int32 {
    if !this.NightCoopIsReceivedPhoto() { return -1; }
    let inventory: array<wref<gameItemData>>;
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    if !transactions.GetItemList(this, inventory) { return -1; }
    let matches = 0;
    let i = 1;
    while i < ArraySize(snapshot) {
        for data in inventory {
            if IsDefined(data) && Equals(ItemID.GetTDBID(data.GetID()), snapshot[i]) {
                matches += 1;
                break;
            }
        }
        i += 2;
    }
    return matches;
}

@addField(GameObject)
private let m_nightCoopPhotoRefreshed: array<ItemID>;

@addMethod(GameObject)
public final func NightCoopPhotoApplySlots(snapshot: array<TweakDBID>) -> String {
    if !this.NightCoopIsReceivedPhoto() { return "excluded: not a received photo actor"; }
    if ArraySize(snapshot) > 108 || ArraySize(snapshot) % 2 != 0 { return "rejected: snapshot size"; }
    let outfit = OutfitSystem.GetInstance(this.GetGame());
    if !IsDefined(outfit) { return "waiting: Equipment-EX"; }
    let allowed = outfit.GetOutfitSlots();
    let slots: array<TweakDBID>;
    let records: array<TweakDBID>;
    let ids: array<ItemID>;
    let inventory: array<wref<gameItemData>>;
    let transactions = GameInstance.GetTransactionSystem(this.GetGame());
    if !transactions.GetItemList(this, inventory) { return "waiting: photo inventory"; }
    let i = 0;
    // Validate the WHOLE mapping before any attachment mutation.
    while i < ArraySize(snapshot) {
        let slot = snapshot[i];
        let record = snapshot[i + 1];
        if !ArrayContains(allowed, slot) || ArrayContains(slots, slot)
            || ArrayContains(records, record) || !IsDefined(TweakDBInterface.GetClothingRecord(record)) {
            return "rejected: unknown slot, duplicate or non-clothing record";
        }
        ArrayPush(slots, slot);
        ArrayPush(records, record);
        let receivedID = ItemID.None();
        for data in inventory {
            if IsDefined(data) && Equals(ItemID.GetTDBID(data.GetID()), record) {
                receivedID = data.GetID();
                break;
            }
        }
        if !ItemID.IsValid(receivedID) { return s"waiting: received clothing \(TDBID.ToStringDEBUG(record))"; }
        ArrayPush(ids, receivedID);
        i += 2;
    }
    let spider = t"Items.raid_psy_visor4_accessories_silver";
    let spiderProxy = this.NightCoopSpiderPhotoRecord();
    let spiderDetails = "";
    // Remove this ephemeral copy if its source is no longer worn. It must not
    // survive a received outfit update that unequips the accessory.
    if !ArrayContains(records, spider) {
        for slot in allowed {
            let stale = transactions.GetItemInSlot(this, slot);
            if IsDefined(stale) && Equals(ItemID.GetTDBID(stale.GetItemID()), spiderProxy) {
                transactions.RemoveItemFromSlot(this, slot);
                ArrayRemove(this.m_nightCoopPhotoRefreshed, stale.GetItemID());
            }
        }
        this.m_nightCoopSpiderProxySubmitted = false;
    }
    i = 0;
    // Validate the source snapshot and received original first, then substitute
    // only this photo actor's separate TPP record. Never preview-grant the original.
    while i < ArraySize(records) {
        if Equals(records[i], spider) && TDBID.IsValid(spiderProxy) {
            if !IsDefined(TweakDBInterface.GetClothingRecord(spiderProxy)) { return "waiting: spider photo record"; }
            if !this.m_nightCoopSpiderProxyTried {
                this.m_nightCoopSpiderProxyTried = true;
                // Keep the same concrete request identity for grant and preview.
                // Never reconstruct FromTDBID independently for the equip call.
                let request = ItemID.FromTDBID(spiderProxy);
                this.m_nightCoopSpiderProxyID = transactions.CreatePreviewItemID(request);
                this.m_nightCoopSpiderProxyGiven = transactions.GivePreviewItemByItemID(this, request);
            }
            if !this.m_nightCoopSpiderProxyGiven { return "spider photo-only copy was not granted; original not removed"; }
            let previewData = transactions.GetItemData(this, this.m_nightCoopSpiderProxyID);
            if !IsDefined(previewData) { return "waiting: spider preview inventory; original not removed"; }
            if !Equals(previewData.GetID(), this.m_nightCoopSpiderProxyID)
                || !Equals(ItemID.GetTDBID(previewData.GetID()), spiderProxy) {
                return "rejected: spider preview identity mismatch; original not removed";
            }
            records[i] = spiderProxy;
            ids[i] = previewData.GetID();
            spiderDetails = s"; spider copy \(TDBID.ToStringDEBUG(spiderProxy)) -> \(TDBID.ToStringDEBUG(slots[i]))";
        }
        i += 1;
    }
    let removed = 0;
    let moved = 0;
    let correct = 0;
    let failed = 0;
    let conflicts = 0;
    let refreshed = 0;
    // Remove misplaced items first so a swap cannot evict another mapped item.
    for slot in allowed {
        let current = transactions.GetItemInSlot(this, slot);
        if IsDefined(current) {
            let record = ItemID.GetTDBID(current.GetItemID());
            let index = ArrayFindFirst(records, record);
            if index >= 0 && NotEquals(slot, slots[index]) {
                transactions.RemoveItemFromSlot(this, slot);
                ArrayRemove(this.m_nightCoopPhotoRefreshed, current.GetItemID());
                removed += 1;
            }
        }
    }
    i = 0;
    while i < ArraySize(slots) {
        let current = transactions.GetItemInSlot(this, slots[i]);
        if IsDefined(current) && Equals(ItemID.GetTDBID(current.GetItemID()), records[i]) {
            correct += 1;
        } else {
            // Let the transaction system replace this original in place, only
            // after the new preview exists. Do not pre-remove the source item.
            if IsDefined(current) && !(Equals(records[i], spiderProxy)
                && Equals(ItemID.GetTDBID(current.GetItemID()), spider)) {
                conflicts += 1;
            } else {
                if Equals(records[i], spiderProxy) && this.m_nightCoopSpiderProxySubmitted {
                    spiderDetails += "; spider pending after accepted attach";
                } else {
                    if transactions.AddItemToSlot(this, slots[i], ids[i], true) {
                        moved += 1;
                        if Equals(records[i], spiderProxy) { this.m_nightCoopSpiderProxySubmitted = true; }
                    } else {
                        failed += 1;
                        if Equals(records[i], spiderProxy) { spiderDetails += "; spider attach rejected"; }
                    }
                }
            }
        }
        current = transactions.GetItemInSlot(this, slots[i]);
        if IsDefined(current) && Equals(ItemID.GetTDBID(current.GetItemID()), records[i])
            && !ArrayContains(this.m_nightCoopPhotoRefreshed, current.GetItemID()) {
            // Rebuild the known attachment, once; do not force arbitrary mesh flags.
            transactions.RefreshAttachment(this, slots[i]);
            ArrayPush(this.m_nightCoopPhotoRefreshed, current.GetItemID());
            refreshed += 1;
        }
        // Remove other copies of this original only when its replacement is
        // actually attached. A failed or pending grant must not erase it.
        if Equals(records[i], spiderProxy) && IsDefined(current)
            && Equals(ItemID.GetTDBID(current.GetItemID()), spiderProxy)
            && current.IsVisualSpawnAttached() {
            this.m_nightCoopSpiderProxyAttached = true;
            for slot in allowed {
                if !Equals(slot, slots[i]) {
                    let originalItem = transactions.GetItemInSlot(this, slot);
                    if IsDefined(originalItem) && Equals(ItemID.GetTDBID(originalItem.GetItemID()), spider) {
                        transactions.RemoveItemFromSlot(this, slot);
                        ArrayRemove(this.m_nightCoopPhotoRefreshed, originalItem.GetItemID());
                    }
                }
            }
            spiderDetails += "; spider visual attached";
        } else {
            if Equals(records[i], spiderProxy) && this.m_nightCoopSpiderProxyAttached {
                // A previously completed copy was evicted by a later appearance
                // rebuild. Permit a new submission after that known transition.
                this.m_nightCoopSpiderProxyAttached = false;
                this.m_nightCoopSpiderProxySubmitted = false;
                ArrayRemove(this.m_nightCoopPhotoRefreshed, this.m_nightCoopSpiderProxyID);
            }
        }
        i += 1;
    }
    return s"SDK exact slots \(ArraySize(slots)); correct \(correct); moved \(moved); removed \(removed); refresh \(refreshed); conflicts \(conflicts); failed \(failed)\(spiderDetails)";
}


// Only photo-owned copies use these records. Original wearable records and their
// first-person camera suffix are never modified.
public class NightCoopPhotoSpiderRecords extends ScriptableTweak {
    protected func OnApply() -> Void {
        let original = t"Items.raid_psy_visor4_accessories_silver";
        if !IsDefined(TweakDBInterface.GetClothingRecord(original)) { return; }
        let suffixes: array<TweakDBID>;
        let batch = TweakDBManager.StartBatch();
        batch.CloneRecord(n"Items.NCoopPhotoSpiderSilverFemale", original);
        batch.CloneRecord(n"Items.NCoopPhotoSpiderSilverMale", original);
        batch.SetFlat(t"Items.NCoopPhotoSpiderSilverFemale.appearanceName", n"raid_psy_visor4_accessories_silver_&Female&TPP");
        batch.SetFlat(t"Items.NCoopPhotoSpiderSilverMale.appearanceName", n"raid_psy_visor4_accessories_silver_&Male&TPP");
        batch.SetFlat(t"Items.NCoopPhotoSpiderSilverFemale.appearanceSuffixes", suffixes);
        batch.SetFlat(t"Items.NCoopPhotoSpiderSilverMale.appearanceSuffixes", suffixes);
        batch.UpdateRecord(t"Items.NCoopPhotoSpiderSilverFemale");
        batch.UpdateRecord(t"Items.NCoopPhotoSpiderSilverMale");
        batch.Commit();
    }
}

@addField(GameObject)
private let m_nightCoopSpiderProxyID: ItemID;

@addField(GameObject)
private let m_nightCoopSpiderProxyAttached: Bool;

@addField(GameObject)
private let m_nightCoopSpiderProxyTried: Bool;

@addField(GameObject)
private let m_nightCoopSpiderProxyGiven: Bool;

@addField(GameObject)
private let m_nightCoopSpiderProxySubmitted: Bool;

@addMethod(GameObject)
private final func NightCoopSpiderPhotoRecord() -> TweakDBID {
    if !this.NightCoopIsReceivedPhoto() { return TDBID.None(); }
    if Equals(this.GetTemplatePath(), r"base\\characters\\entities\\player\\photo_mode\\player_wa_photomode.ent") {
        return t"Items.NCoopPhotoSpiderSilverFemale";
    }
    if Equals(this.GetTemplatePath(), r"base\\characters\\entities\\player\\photo_mode\\player_ma_photomode.ent") {
        return t"Items.NCoopPhotoSpiderSilverMale";
    }
    return TDBID.None();
}
