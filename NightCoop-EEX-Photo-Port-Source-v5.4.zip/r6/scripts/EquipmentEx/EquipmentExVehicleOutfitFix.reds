import EquipmentEx.OutfitSystem

class EEXVehicleAppearanceRefreshCallback extends DelayCallback {
    private let m_outfit: wref<OutfitSystem>;

    public func Call() -> Void {
        if IsDefined(this.m_outfit) && this.m_outfit.IsActive() {
            this.m_outfit.ReapplyOutfitAfterVehicleChange();
        }
    }

    public static func Create(outfit: ref<OutfitSystem>) -> ref<EEXVehicleAppearanceRefreshCallback> {
        let self = new EEXVehicleAppearanceRefreshCallback();
        self.m_outfit = outfit;
        return self;
    }
}

@addMethod(PlayerPuppet)
private func ScheduleEEXVehicleAppearanceRefresh(delay: Float) -> Void {
    let localPlayer = GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerMainGameObject();
    if IsDefined(localPlayer) && Equals(this.GetEntityID(), localPlayer.GetEntityID()) {
        let outfit = OutfitSystem.GetInstance(this.GetGame());
        if IsDefined(outfit) && outfit.IsActive() {
            let callback = EEXVehicleAppearanceRefreshCallback.Create(outfit);
            GameInstance.GetDelaySystem(this.GetGame()).DelayCallback(callback, delay, false);
        }
    }
}

@wrapMethod(PlayerPuppet)
protected cb func OnMountingEvent(evt: ref<MountingEvent>) -> Bool {
    let result = wrappedMethod(evt);
    if Equals(evt.relationship.otherMountableType, gameMountingObjectType.Vehicle) {
        // Vehicle mounting and camera setup can update attachments in separate ticks.
        this.ScheduleEEXVehicleAppearanceRefresh(0.1);
        this.ScheduleEEXVehicleAppearanceRefresh(0.5);
    }
    return result;
}

@wrapMethod(PlayerPuppet)
protected cb func OnUnmountingEvent(evt: ref<UnmountingEvent>) -> Bool {
    let result = wrappedMethod(evt);
    if Equals(evt.relationship.otherMountableType, gameMountingObjectType.Vehicle) {
        this.ScheduleEEXVehicleAppearanceRefresh(0.1);
    }
    return result;
}

// Reapply after the vehicle camera has changed to third person. The mount event
// alone runs before the final vehicle-camera appearance update on some rides.
@wrapMethod(PlayerPuppet)
protected cb func OnDriverCombatCameraChange(inTPP: Bool) -> Bool {
    let result = wrappedMethod(inTPP);
    if inTPP {
        this.ScheduleEEXVehicleAppearanceRefresh(0.35);
        this.ScheduleEEXVehicleAppearanceRefresh(0.8);
    }
    return result;
}
