// Registration for the 0.2.0 port. The native configured-item bridge and
// vehicle callbacks remain separate; SDK definitions are supplied by NightCoop.
@if(ModuleExists("NightCoop"))
public class NightCoopEEXPortRegistration extends ScriptableService {
    private cb func OnInitialize() {
        if NightCoopSdk.Version() > 0 {
            // NeededByAll | UsesHooks; actual game wrappers always call original.
            if NightCoopSdk.RegisterMod("eulaliaworks.eex_bridge", "Equipment-EX NightCoop bridge", "0.2.0-port.1", 1, 262145) {
                NightCoopSdk.HookDeclare("eulaliaworks.eex_bridge", "PlayerPuppet", "OnMountingEvent", 2);
                NightCoopSdk.HookDeclare("eulaliaworks.eex_bridge", "PlayerPuppet", "OnUnmountingEvent", 2);
                NightCoopSdk.HookDeclare("eulaliaworks.eex_bridge", "PlayerPuppet", "OnDriverCombatCameraChange", 2);
                NightCoopSdk.HookDeclare("eulaliaworks.eex_bridge", "PhotoModePlayerEntityComponent", "SetupInventory", 2);
                NightCoopSdk.HookDeclare("eulaliaworks.eex_bridge", "PhotoModePlayerEntityComponent", "OnItemAddedToSlot", 2);
                NightCoopSdk.Log("eulaliaworks.eex_bridge", 1, "0.2.0 port registered: configured item IDs, EX slots and local vehicle refresh; photo visuals still require co-op testing.");
            }
        }
    }
}
